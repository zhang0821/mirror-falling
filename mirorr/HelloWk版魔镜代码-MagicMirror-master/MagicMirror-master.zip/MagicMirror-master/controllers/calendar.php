<?php
  include "functions/gzip.php";
	$url = $_GET["url"];
	echo get_url($url);
?>
